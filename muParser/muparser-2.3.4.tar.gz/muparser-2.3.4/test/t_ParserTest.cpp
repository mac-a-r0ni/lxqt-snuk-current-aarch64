#include "muParserTest.h"

using namespace mu::Test;

int main(int, char**)
{
  ParserTester tester;
  return tester.Run();
}
